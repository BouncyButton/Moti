// This sample shows creation of a [Card] widget that can be tapped. When
// tapped this [Card]'s [InkWell] displays an "ink splash" that fills the
// entire card.

import 'package:flutter/material.dart';
import 'todo.dart';
import 'Task.dart';
import 'TaskAdder.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  PageController controller = PageController();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Code Sample for material.Card',
        theme: ThemeData(
          primarySwatch: Colors.blueGrey,
        ),
        home: PageView(
          controller: controller,
          children: <Widget>[
            new Task(controller: controller),
            new TaskAdder(controller: controller),
            Container(color: Colors.blueAccent),
          ],
          scrollDirection: Axis.vertical,
        )

        // new TodoList()

//      Scaffold(
//          appBar: AppBar(
//            title: Text(
//                'A fluffy bunny jumped...'
//            ),
//          ),
//          body: Center(
//              child: Text('... and it was cute.')
//          )
//      ),

        );
  }
}

class MyStatelessWidget extends StatelessWidget {
  MyStatelessWidget({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        splashColor: Colors.blue.withAlpha(30),
        onTap: () {
          /* ... */
        },
        child: Text('A card that can be tapped'),
      ),
    );
  }
}
