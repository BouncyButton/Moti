import 'package:flutter/material.dart';

class TaskAdder extends StatefulWidget {
  final PageController controller;
  var repeat = false;

  TaskAdder({Key key, this.controller}) : super(key: key);

  @override
  createState() => new TaskAdderState();
}

class TaskAdderState extends State<TaskAdder> {
  PageController controller;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        body: new GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: new Container(
              color: Colors.lightBlue[100],
              child: Column(
                children: <Widget>[
                  // Textbox
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 50.0, horizontal: 15.0),
                    child: Card(
                      child: TextField(
                        // autofocus: true,
                        style: TextStyle(fontSize: 24.0),
                        decoration: InputDecoration(
                            labelStyle: TextStyle(fontSize: 20.0),
                            contentPadding: const EdgeInsets.all(20.0),
                            labelText: 'Describe your task.'),
                        maxLines: 2,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      child: Row(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: ChoiceChip(
                              label: Text("Repeat"),
                              avatar: Icon(Icons.repeat),
                              padding: EdgeInsets.all(5.0),
                              selected: widget.repeat,
                              onSelected: (var value) {
                                setState(() {
                                  widget.repeat = !widget.repeat;
                                });
                                print(value);
                              },
                              selectedColor: Colors.greenAccent,
                              labelStyle: widget.repeat
                                  ? TextStyle(color: Colors.black)
                                  : TextStyle(color: Colors.black38),
                              shape: widget.repeat
                                  ? RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16.0),
                                      side: BorderSide(
                                          color: Colors.black, width: 0.5))
                                  : RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16.0),
                                      side: BorderSide(
                                          color: Colors.white, width: 0.5)),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: ChoiceChip(
                              label: Text("Repeat"),
                              avatar: Icon(Icons.repeat),
                              padding: EdgeInsets.all(5.0),
                              selected: widget.repeat,
                              onSelected: (var value) {
                                setState(() {
                                  widget.repeat = !widget.repeat;
                                });
                                print(value);
                              },
                              selectedColor: Colors.greenAccent,
                              labelStyle: widget.repeat
                                  ? TextStyle(color: Colors.black)
                                  : TextStyle(color: Colors.black38),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            )));
  }
}
