import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class Task extends StatefulWidget {
  final PageController controller;

  const Task({Key key, this.controller}) : super(key: key);

  @override
  createState() => new TaskState();
}

class TaskState extends State<Task> {
  PageController controller;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Main View!
        Card(
          child: CustomScrollView(
            slivers: <Widget>[
              SliverAppBar(
                  pinned: true,
                  expandedHeight: 250.0,
                  flexibleSpace: FlexibleSpaceBar(
                    title: Text('Fare cose'),
                  ),
                  actions: <Widget>[
                    IconButton(
                      icon: const Icon(Icons.edit),
                      tooltip: 'Edit title',
                      onPressed: () {
                        print('Edit!');
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.share),
                      tooltip: 'Share this!',
                      onPressed: () {
                        print('Share');
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.photo_camera),
                      tooltip: 'Take a photo',
                      onPressed: () {
                        print('Photo');
                      },
                    ),
                  ]),
              SliverList(
                delegate: SliverChildListDelegate(
                  [
                    _createProgressBar(context, 6, 9),
                    _createItem("repeat", "15", "Passeggiare la sera",
                        "Added on 20/6/2019", Colors.green),
                    _createItem("repeat", "3", "Mangiare bene",
                        "Added on 19/6/2019", Colors.deepPurple),
                    _createItem("repeat", "2", "Dormire tanto",
                        "Added on 18/6/2019", Colors.deepOrange),
                    _createItem("once", "", "Andare a fare X",
                        "Added on 18/6/2019", Colors.green),
                    _createItem("repeat", "14", "Bere spesso",
                        "Added on 18/6/2019", Colors.green),
                    _createItem("once", "", "Fare cose", "Added on 18/6/2019",
                        Colors.red),
                    _createItem(
                        "once", "", "Boh", "Added on 18/6/2019", Colors.green),
                    _createItem(
                        "once", "", "Buh", "Added on 18/6/2019", Colors.green),
                  ],
                ),
              ),
            ],
          ),
        ),
        // Add item-bar

        Positioned(
          bottom: -10.0,
          left: 10.0,
          right: 10.0,
          child: Card(
            elevation: 20.0,
            color: Colors.lightBlue[100],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8.0),
            ),

            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () {
                setState(() {
                  widget.controller.animateToPage(1, duration: Duration(milliseconds: 500), curve: Curves.ease);
                });
              },

              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.white,
                      Colors.lightBlue[100],
                    ],
                    stops: [
                      0.5,
                      0.8,
                    ],

                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(16.0),
                ),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(7.0),
                      // child: Icon(Icons.add_circle_outline, size:30.0)
                    ),
                    Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Text("Swipe up to create a new item",
                          style: TextStyle(color: Colors.black87)),
                    ),
                    Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Icon(Icons.keyboard_arrow_up, size: 20.0)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

Widget _createProgressBar(var context, var min, var max) {
  return new Stack(children: <Widget>[
    new Column(
      children: <Widget>[
        new Container(
          color: Colors.blueGrey,
          height: 10.0,
          width: MediaQuery.of(context).size.width,
        ),
      ],
    ),
    new Container(
        color: Colors.greenAccent,
        height: 10.0,
        width: MediaQuery.of(context).size.width * min / max)
  ]);
}

//
//    Column(
//      children: <Widget>[
//        new ListTile(
//          title: new Text("\t$min/$max done"),
//        ),
//        FractionallySizedBox(
//          widthFactor: min/max,
//          child:
//            Container(
//              height: 10.0, color: Colors.greenAccent,
//            ),
//        ),
//        FractionallySizedBox(
//          widthFactor: 1-min/max,
//          child:
//            Container()
//        )
//
//      ],
//    ),

Widget _createItem(
    var repetition, var centerText, var title, var date, var color) {
  return new Card(
    child: new Slidable(
      actionPane: SlidableDrawerActionPane(),
      actionExtentRatio: 1,
      child: new Container(
        color: color[100],
        child: new ListTile(
          leading: _getLeadingIcon(repetition, color, centerText),
          title: new Text(title),
          subtitle: new Text(date),
        ),
      ),
      actions: <Widget>[
        new IconSlideAction(
          caption: 'Done',
          color: Colors.greenAccent,
          icon: Icons.check_circle_outline,
          onTap: () => debugPrint('Done!'),
        ),
      ],
      secondaryActions: <Widget>[
        new IconSlideAction(
          caption: 'Delete',
          color: Colors.red,
          icon: Icons.delete_forever,
          onTap: () => debugPrint('Delete!'),
        ),
      ],
    ),
  );
}

Widget _getLeadingIcon(var repetition, var color, var centerText) {
  if (repetition == "repeat") {
    return Column(
      children: <Widget>[
        CircleAvatar(
          backgroundColor: Color.fromRGBO(255, 255, 255, 0.5),
          child: new Text(centerText),
          foregroundColor: Colors.black87,
        ),
        Padding(
          padding: EdgeInsets.all(2.0),
        ),
        Text(
          'Daily',
          textScaleFactor: 0.8,
        )
      ],
    );
  } else if (repetition == "once") {
    return Column(
      children: <Widget>[
        CircleAvatar(
          backgroundColor: Color.fromRGBO(255, 255, 255, 0.5),
          child: new Text(centerText),
          foregroundColor: Colors.black87,
        ),
        Padding(
          padding: EdgeInsets.all(2.0),
        ),
        Text(
          'Once',
          textScaleFactor: 0.8,
        )
      ],
    );
  }
}
